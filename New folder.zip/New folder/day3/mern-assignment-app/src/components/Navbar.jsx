function Navbar() {
    return (
        <nav className='topbar'>
            <ul>
                <li>
                    <a href={`/`}>Home</a>
                </li>
                <li>
                    <a href={`/projects`}>Available houses</a>
                </li>
                <li>
                    <a href={`/groups`}>Agents</a>
                </li>
                <li>
                    <a href={`/projects/create`}>Add Property</a>
                </li>
            </ul>
        </nav>
    )
}

export default Navbar